https://github.com/wang-bin/avbuild
